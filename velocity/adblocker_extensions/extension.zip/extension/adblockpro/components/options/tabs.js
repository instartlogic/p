$('.nav').on('click', 'li', function(e){
  e.preventDefault();
  $(this)
    .siblings()
      .removeClass('active')
      .end()
    .addClass('active');
  $('.tab')
    .hide()
    .parent()
    .find($(this).find('a').attr('href'))
    .show();
});