var backgroundPage = chrome.extension.getBackgroundPage();
var imports = ["require", "isWhitelisted", "extractHostFromURL", "refreshIconAndContextMenu"];
for (var i = 0; i < imports.length; i++)
  window[imports[i]] = backgroundPage[imports[i]];

var Filter = require("filterClasses").Filter;
var FilterStorage = require("filterStorage").FilterStorage;

var tab = null;


var enableBtn = {
  btn: $("#enabled"),
  state: true,
  set: function(state) {
    this.state = state;
    this.btn
      .children()
      .hide()
      .end()
      .find(state ? '.disableFS' : '.enableFS')
      .show()
      .end();
    return this;
  },
  init: function(state) {
    this.btn
      .on('click', this.toggle)
      .show();
    this.set(state);
  },
  toggle: function(e) {
    console.log("clikes");
    enableBtn.set(!enableBtn.state);
    if (enableBtn.state) {
      // Remove any exception rules applying to this URL
      var filter = isWhitelisted(tab.url);
      while (filter) {
        FilterStorage.removeFilter(filter);
        if (filter.subscriptions.length)
          filter.disabled = true;
        filter = isWhitelisted(tab.url);
      }
    } else {
      var host = extractHostFromURL(tab.url).replace(/^www\./, "");
      var filter = Filter.fromText("@@||" + host + "^$document");
      if (filter.subscriptions.length && filter.disabled)
        filter.disabled = false;
      else {
        filter.disabled = false;
        FilterStorage.addFilter(filter);
      }
    }
    refreshIconAndContextMenu(tab);
  }
};


function init() {
  // Attach event listeners
  //- $("#enabled").click(toggleEnabled);
  $("#clickHideButton").click(activateClickHide);
  $("#cancelButton").click(cancelClickHide);

  // Ask content script whether clickhide is active. If so, show cancel button.
  // If that isn't the case, ask background.html whether it has cached filters. If so,
  // ask the user whether she wants those filters.
  // Otherwise, we are in default state.
  chrome.windows.getCurrent(function(w) {
    chrome.tabs.getSelected(w.id, function(t) {
      tab = t;
      enableBtn.init(!isWhitelisted(tab.url));

      chrome.tabs.sendMessage(tab.id, {
        reqtype: "get-clickhide-state"
      }, function(response) {
        console.log(response);
        if (response && response.active)
          clickHideActiveStuff();
        else
          clickHideInactiveStuff();
      });
    });
  });
}
$(init);

function activateClickHide() {
  clickHideActiveStuff();
  chrome.tabs.sendMessage(tab.id, {
    reqtype: "clickhide-activate"
  });
  // Close the popup after a few seconds, so user doesn't have to
  activateClickHide.timeout = window.setTimeout(window.close, 5000);
}

function cancelClickHide() {
  if (activateClickHide.timeout) {
    window.clearTimeout(activateClickHide.timeout);
    activateClickHide.timeout = null;
  }
  clickHideInactiveStuff();
  chrome.tabs.sendMessage(tab.id, {
    reqtype: "clickhide-deactivate"
  });
}

function clickHideActiveStuff() {
  enableBtn.btn.hide();
  document.getElementById("clickHideInactiveStuff").style.display = "none";
  document.getElementById("clickHideActiveStuff").style.display = "inherit";
  document.getElementById("options").style.display = "none";
}

function clickHideInactiveStuff() {
  enableBtn.btn.show();
  document.getElementById("clickHideActiveStuff").style.display = "none";
  document.getElementById("options").style.display = "inherit";
  document.getElementById("clickHideInactiveStuff").style.display = "inherit";
}

function showOptions(e){
  chrome.tabs.create({
    url: chrome.extension.getURL("components/options/options.html")
  });
}
$('#options').on('click',showOptions)